#ifndef UTILS_H
#define UTILS_H

void print_progress(unsigned long current, unsigned long total);
unsigned long file_size(const char *filename);

#endif