#ifndef DECOMPRESS_H
#define DECOMPRESS_H
int decompress_file(const char *in, const char *out);
#endif
