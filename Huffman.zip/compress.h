#ifndef COMPRESS_H
#define COMPRESS_H
int compress_file(const char *in, const char *out);
#endif